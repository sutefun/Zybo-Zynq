
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
/* Xilinx includes. */
#include "xil_printf.h"
#include "xparameters.h"

/*
 * include saya
 */
#include "xgpio.h"
#include "PmodGPIO.h"


#define TIMER_ID	1
#define DELAY_10_SECONDS	10000UL
#define DELAY_1_SECOND		1000UL
#define TIMER_CHECK_THRESHOLD	9

/* The queue used by the Tx and Rx tasks, as described at the top of this
file. */
static QueueHandle_t xQueue = NULL;
char HWstring[15] = "Hello World";
long RxtaskCntr = 0;

/*
 * variabel saya
 */

XGpio button;
PmodGPIO myDevice;
void readButton();
void pmodLed();

int main( void )
{
	/* inisialisasi Xgpio*/
	XGpio_Initialize(&button, XPAR_GPIO_BUTTON_DEVICE_ID);
	XGpio_SetDataDirection(&button , 1 , 0xFFFFFFFF);

	/*inisialisasi pmodGpio dan set pin semua jadi output */
	GPIO_begin(&myDevice, XPAR_PMODGPIO_0_AXI_LITE_GPIO_BASEADDR, 0x00);
	GPIO_setPins(&myDevice, 0x00);

	xil_printf( "Hello from Freertos example main\r\n" );

	xTaskCreate( readButton,
						 ( const char * ) "readButton",
						 configMINIMAL_STACK_SIZE,
						 NULL,
						 tskIDLE_PRIORITY ,
						 NULL );

	xTaskCreate( pmodLed,
							 ( const char * ) "pmodLed",
							 configMINIMAL_STACK_SIZE,
							 NULL,
							 tskIDLE_PRIORITY +1 ,
							 NULL );

	xQueue = xQueueCreate( 	1,						/* There is only one space in the queue. */
							sizeof( uint32_t ) );	/* Each space in the queue is large enough to hold a uint32_t. */


	configASSERT( xQueue );

	vTaskStartScheduler();

	for( ;; );
}


void readButton(){
	uint32_t buttonVal;

	while(1){
		//vTaskDelay( pdMS_TO_TICKS( DELAY_1_SECOND ) );
		//xil_printf("readButton\n");
		buttonVal = XGpio_DiscreteRead(&button , 1);
		xQueueSend(xQueue, &buttonVal , 0UL);
	}
//end of readButton
}

void pmodLed(){
	uint32_t buttonVal=0;

	while(1){
		vTaskDelay( pdMS_TO_TICKS( DELAY_1_SECOND ) );
		xQueueReceive(xQueue, &buttonVal , portMAX_DELAY);

		if(buttonVal== 0b0001){
			xil_printf("button val 1\n");
			GPIO_setPin(&myDevice, 4 , 1);

		}
		if(buttonVal== 0b0010){
			xil_printf("button val 2\n");

			for(int i=0;i<10;i++){
				GPIO_setPin(&myDevice, 4, 1);
				delay(300000);
				GPIO_setPin(&myDevice, 4 , 0);
				delay(300000);

			}

		}
		if(buttonVal == 0b0100){
			xil_printf("button val 4\n");
			GPIO_setPin(&myDevice, 4 , 0);
		}

	}
//end of pmodLed
}


